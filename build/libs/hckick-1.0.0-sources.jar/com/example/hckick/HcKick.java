package com.example.hckick;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.minecraft.class_2561;
import net.minecraft.class_3222;

public class HcKick implements ModInitializer {

    public static final String MOD_ID = "hckick";

    @Override
    public void onInitialize() {
        ServerLivingEntityEvents.AFTER_DEATH.register((entity, damageSource) -> {
            if (entity instanceof class_3222 player) {
                class_2561 deathMessage = player.method_6066().method_5548();
                player.field_13987.method_52396(deathMessage);
            }
        });
    }
}
